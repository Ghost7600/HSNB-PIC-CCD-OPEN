/* 
 * File:   i2c.h
 * Author: ryanarodriguez
 *
 * Created on August 1, 2014, 11:08 AM
 */

#ifndef I2_H
#define	I2_H

#define I2C_ADDR 0xA2

void i2c_init(void);



#endif	/* I2C_H */

